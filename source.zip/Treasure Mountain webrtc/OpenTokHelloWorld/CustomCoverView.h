//
//  CustomCoverView.h
//  Treasure Mountain WebRTC
//
//  Created by brightstar on 4/11/13.
//
//

#import <UIKit/UIKit.h>

@interface CustomCoverView : UIView

@property (assign) CGFloat transX;
@property (assign) CGFloat transY;
@property (assign) CGFloat transWidth;
@property (assign) CGFloat transHeight;

@end
