//
//  CustomLoader.m
//  Classmon
//
//  Created by Ayaz Alavi on 4/24/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CustomLoader.h"

@implementation CustomLoader
@synthesize message, activityIndicator;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        UIView *wrapper = [[UIView alloc] initWithFrame:frame];
        wrapper.backgroundColor = [UIColor blackColor];
        wrapper.layer.opacity = 0.4;
        //s[self addSubview:wrapper];
        
        UIView *box = [[UIView alloc] initWithFrame:CGRectMake(60, 210, 200, 60)];
        //box.backgroundColor = [UIColor blackColor];
        box.backgroundColor = [UIColor clearColor];
        box.center = self.center;
        //box.layer.cornerRadius = 8;        
        
        message = [[UILabel alloc] initWithFrame:CGRectMake(70, 20, 120, 20)];
        message.text = @"Loading...Please wait";
        message.textColor = [UIColor whiteColor];
        message.backgroundColor = [UIColor clearColor];
        message.font = [UIFont fontWithName:@"Helvetica" size:12];
        
        //[box addSubview:message];
        
        activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        //activityIndicator.frame = CGRectMake(15.0, 10.0, 40.0, 40.0);	
        [activityIndicator startAnimating];
        [self addSubview:activityIndicator];
        activityIndicator.center = self.center;
        
       // [self addSubview:box];
        
        self.backgroundColor = [UIColor clearColor];
  
    }
    return self;
}
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    
}


@end
