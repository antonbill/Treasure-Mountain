//
//  CustomCoverView.m
//  Treasure Mountain WebRTC
//
//  Created by brightstar on 4/11/13.
//
//

#import "CustomCoverView.h"

@implementation CustomCoverView

@synthesize transX, transY, transWidth, transHeight;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];

    if (self) {
        
        transX = 0;
        transY = 0;
        transWidth = self.frame.size.width;
        transHeight = self.frame.size.height;
        self.backgroundColor = [UIColor clearColor];
        [self setNeedsDisplay];
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
    if (transX == 0 && transY == 0) {
        return;
    }
    
    CGContextRef cRef = UIGraphicsGetCurrentContext();
    
    CGContextSetRGBFillColor(cRef, 0.0, 0.0, 0.0, 1.0);
    
    CGContextFillRect(cRef, CGRectMake(0, 0, transX, self.frame.size.height));
    
    CGContextFillRect(cRef, CGRectMake(transX, 0, transWidth, transY));

    CGContextFillRect(cRef, CGRectMake(transX, transY+transHeight, transWidth, transY));
    
    CGContextFillRect(cRef, CGRectMake(transX+transWidth, 0, transX, self.frame.size.height));
    
}

@end
