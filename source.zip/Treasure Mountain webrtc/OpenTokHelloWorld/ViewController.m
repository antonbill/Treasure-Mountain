//
//  ViewController.m
//  SampleApp
//
//  Created by Charley Robinson on 12/13/11.
//  Copyright (c) 2011 Tokbox, Inc. All rights reserved.
//

#import "ViewController.h"
#import "CustomCoverView.h"

#define isiPad  UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad
#define IS_IPHONE_5 ([[UIScreen mainScreen] bounds].size.height == 568.0f)

#define DEGREES_TO_RADIANS(angle) ((angle) / 180.0 * M_PI)

#define SCREEN_WIDTH (isiPad ? 768 : 320)
#define SCREEN_HEIGHT (isiPad ? 1004 : 460)

#define PUBLISHER_WIDtH (isiPad ? 200 : 120)
#define PUBLISHER_HEIGHT (isiPad ? 150 : 90)

@interface ViewController()
- (void) setCoverviewTransFrame:(CGRect)tramsFrame;
@end

@implementation ViewController {
    OTSession* _session;
    OTPublisher* _publisher;
    OTSubscriber* _subscriber;
    UIInterfaceOrientation oldOrientation;
    CustomCoverView *coverView;
    BOOL blReceived;

}
@synthesize controls, publisherView, loader1, loader2;
static bool portraitOrientation = YES;

// *** Fill the following variables using your own Project info from the Dashboard  ***
// ***                  (https://dashboard.tokbox.com/projects)                     ***
static NSString* const kApiKey = @"22736942";    // Replace with your API Key
static NSString* const kSessionId = @"2_MX4yMjczNjk0Mn5-U3VuIE1hciAzMSAwNjo1NzozMyBQRFQgMjAxM34wLjE3NDE1NjEzfg"; // Replace with your generated Session ID
static NSString* const kToken = @"T1==cGFydG5lcl9pZD0yMjczNjk0MiZzaWc9NzViODgwN2Q4YjU5MGQ1NjM3ZTA2N2I1MzFmOWRkYzE4M2Q1MGE0OTpzZXNzaW9uX2lkPTJfTVg0eU1qY3pOamswTW41LVUzVnVJRTFoY2lBek1TQXdOam8xTnpvek15QlFSRlFnTWpBeE0zNHdMakUzTkRFMU5qRXpmZyZjcmVhdGVfdGltZT0xMzY0NzM4NDg3JmV4cGlyZV90aW1lPTEzNjczMzA0ODcmcm9sZT1wdWJsaXNoZXImY29ubmVjdGlvbl9kYXRhPSZub25jZT03MDM5Nw==";     // Replace with your generated Token (use Project Tools or from a server-side library)

static bool subscribeToSelf = NO; // Change to YES if you want to subscribe to your own stream.

#pragma mark - View lifecycle

- (void)viewDidLoad
{

    [super viewDidLoad];
    
    coverView = nil;
    
    _session = [[OTSession alloc] initWithSessionId:kSessionId delegate:self];
    [self doConnect];
    
    self.publisherView.layer.borderWidth = 2.0;
    self.publisherView.layer.borderColor = [UIColor whiteColor].CGColor;
    self.publisherView.layer.shadowColor = [UIColor blackColor].CGColor;
    self.publisherView.layer.shadowRadius = 4.0f;
    self.publisherView.layer.shadowOpacity = 0.8;
    self.publisherView.layer.shadowOffset = CGSizeMake(0.0, 1.0);
    self.publisherView.layer.cornerRadius = 2.0f;
    
    //  [[UIDevice currentDevice] endGeneratingDeviceOrientationNotifications];
    
    // [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    // [[UIDevice currentDevice] performSelector:@selector(setOrientation:) withObject:(__bridge id)((void*)UIInterfaceOrientationPortrait)];
    
    oldOrientation = UIInterfaceOrientationPortrait;
    if (UIInterfaceOrientationIsLandscape(self.interfaceOrientation)) {
        oldOrientation = self.interfaceOrientation;
        [self willRotateToInterfaceOrientation:self.interfaceOrientation duration:2.0f];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(handleEnterForeground:)
                                                 name: UIApplicationWillEnterForegroundNotification
                                               object: nil];
}

- (void) handleEnterForeground:(NSNotification *)notif {
    _session = [[OTSession alloc] initWithSessionId:kSessionId delegate:self];
    [self doConnect];
}

- (void)viewDidUnload {
    [self setControls:nil];
    [self setPublisherView:nil];
    [self setVideoEnd:nil];
    [self setArrowView:nil];
    [super viewDidUnload];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if (interfaceOrientation == UIInterfaceOrientationLandscapeLeft || interfaceOrientation == UIInterfaceOrientationLandscapeRight || interfaceOrientation == UIInterfaceOrientationPortrait) {
        
        return YES;
    }
    return NO;
}

- (void) willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {

    if (UIInterfaceOrientationIsPortrait(toInterfaceOrientation)) {

        self.publisherView.frame = CGRectMake(9, SCREEN_HEIGHT - self.publisherView.frame.size.height - 31, self.publisherView.frame.size.width, self.publisherView.frame.size.height);
        self.controls.frame = CGRectMake(SCREEN_WIDTH - self.controls.frame.size.width, -20, self.controls.frame.size.width, SCREEN_HEIGHT);
        _publisher.view.frame = CGRectMake(0, 0, self.publisherView.frame.size.width, self.publisherView.frame.size.height);
        self.arrowView.frame = CGRectMake(17, self.controls.frame.size.height - self.arrowView.frame.size.height, self.arrowView.frame.size.width, self.arrowView.frame.size.height);
        self.arrowView.hidden = YES;
        if (loader2 != nil) {
            loader2.frame  = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
            loader2.activityIndicator.center = loader2.center;
        }
    }
    else if (UIInterfaceOrientationIsLandscape(toInterfaceOrientation)) {
        
        self.publisherView.frame = CGRectMake(9, SCREEN_WIDTH - 20 - self.publisherView.frame.size.height - 5, self.publisherView.frame.size.width, self.publisherView.frame.size.height);
        self.controls.frame = CGRectMake(SCREEN_HEIGHT - self.controls.frame.size.width + 20, -20, self.controls.frame.size.width, SCREEN_WIDTH);
        _publisher.view.frame = CGRectMake(0, 0, self.publisherView.frame.size.width, self.publisherView.frame.size.height);
        self.arrowView.frame = CGRectMake(17, self.controls.frame.size.height - self.arrowView.frame.size.height, self.arrowView.frame.size.width, self.arrowView.frame.size.height);
        self.arrowView.hidden = NO;
        if (loader2 != nil) {
            loader2.frame  = CGRectMake(0, 0, SCREEN_HEIGHT+20, SCREEN_WIDTH - 20);
            loader2.activityIndicator.center = loader2.center;
        }
    }
    
    
}

- (void) didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    
    BOOL blScaled;
    
    if (_subscriber.stream.videoDimensions.width < _subscriber.stream.videoDimensions.height) {

        if (self.interfaceOrientation == UIInterfaceOrientationLandscapeLeft || self.interfaceOrientation == UIInterfaceOrientationLandscapeRight) {
            blScaled = NO;
        }
        else {
            blScaled = YES;
        }
        [self changeSubscriberFeedWithScale:(blScaled && oldOrientation == self.interfaceOrientation)];
    }
    else {
        if (self.interfaceOrientation == UIInterfaceOrientationLandscapeLeft || self.interfaceOrientation == UIInterfaceOrientationLandscapeRight) {
            [self changeSubscriberFeedWithScale:YES];
        }
        else {
            if (oldOrientation != UIInterfaceOrientationPortrait) {
                blScaled = YES;
            }
            else {
                blScaled = NO;
            }
            [self changeSubscriberFeedWithScale:blScaled];
        }
    }
    oldOrientation = self.interfaceOrientation;

}

- (void)updateSubscriber {
    for (NSString* streamId in _session.streams) {
        OTStream* stream = [_session.streams valueForKey:streamId];
        if (![stream.connection.connectionId isEqualToString: _session.connection.connectionId]) {
            _subscriber = [[OTSubscriber alloc] initWithStream:stream delegate:self];
            break;
        }
    }
}

- (void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    //    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    //    if (portraitOrientation) {
    //        [[UIDevice currentDevice] performSelector:@selector(setOrientation:) withObject:(__bridge id)((void*)UIInterfaceOrientationPortrait)];
    //    }
    //    else {
    //        [[UIDevice currentDevice] performSelector:@selector(setOrientation:) withObject:(__bridge id)((void*)UIInterfaceOrientationLandscapeLeft)];
    //    }
}

#pragma mark - OpenTok methods

- (void)doConnect
{
    loader1 = [[CustomLoader alloc] initWithFrame:[self.publisherView frame]];
    loader1.message.text = @"Loading...Please wait";
    [self.publisherView addSubview:loader1];
    
    loader2 = [[CustomLoader alloc] initWithFrame:[self.view frame]];
    loader2.message.text = @"Loading...Please wait";
    [self.view insertSubview:loader2 atIndex:0];

    if (!coverView) {
        coverView = [[CustomCoverView alloc] initWithFrame:self.view.frame];
        [self.view addSubview:coverView];
        [self.view bringSubviewToFront:self.publisherView];
        [self.view bringSubviewToFront:self.controls];
    }
    
    [_session connectWithApiKey:kApiKey token:kToken];
}

- (void)doPublish
{
    _publisher = [[OTPublisher alloc] initWithDelegate:self];
    [_publisher setName:[[UIDevice currentDevice] name]];
    [_session publish:_publisher];
    [_publisher.view setFrame:CGRectMake(0, 0, self.publisherView.frame.size.width, self.publisherView.frame.size.height)];
    [self.publisherView addSubview:_publisher.view];

}

- (void) connectWithSession
{
    [_session connectWithApiKey:kApiKey token:kToken];
}

- (void)sessionDidConnect:(OTSession*)session
{
    NSLog(@"sessionDidConnect (%@)", session.sessionId);
    if (_publisher == nil) {
        [self doPublish];
    }
    if (loader1) {
        [loader1 removeFromSuperview];
        loader1 = nil;
    }
}

- (void)sessionDidDisconnect:(OTSession*)session
{
    NSString* alertMessage = [NSString stringWithFormat:@"Session disconnected: (%@)", session.sessionId];
    NSLog(@"sessionDidDisconnect (%@)", alertMessage);
    _publisher = nil;
    // [self showAlert:alertMessage];
}


- (void)session:(OTSession*)mySession didReceiveStream:(OTStream*)stream
{
    NSLog(@"session didReceiveStream (%@)", stream.streamId);
    
    // See the declaration of subscribeToSelf above.
    if ( (subscribeToSelf && [stream.connection.connectionId isEqualToString: _session.connection.connectionId])
        ||
        (!subscribeToSelf && ![stream.connection.connectionId isEqualToString: _session.connection.connectionId])
        ) {
        if (!_subscriber) {
            _subscriber = [[OTSubscriber alloc] initWithStream:stream delegate:self];
        }
    }
}

- (void)session:(OTSession*)session didDropStream:(OTStream*)stream{
    NSLog(@"session didDropStream (%@)", stream.streamId);
    NSLog(@"_subscriber.stream.streamId (%@)", _subscriber.stream.streamId);
    if (!subscribeToSelf
        && _subscriber
        && [_subscriber.stream.streamId isEqualToString: stream.streamId])
    {
        _subscriber = nil;
        [self updateSubscriber];
    }
}

- (void)subscriberDidConnectToStream:(OTSubscriber*)subscriber
{
    //[[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    NSLog(@"subscriberDidConnectToStream (%@)", subscriber.stream.connection.connectionId);
    //  NSLog(@"stream size: %@", NSStringFromCGSize(subscriber.stream.videoDimensions));
    UIInterfaceOrientation interfaceOrientation = [[UIApplication sharedApplication] statusBarOrientation];
    if (UIInterfaceOrientationIsLandscape(interfaceOrientation)) {
        if (IS_IPHONE_5) {
            [_subscriber.view setFrame:CGRectMake(0, 0, 568, SCREEN_WIDTH-20)];
        }
        else {
            [_subscriber.view setFrame:CGRectMake(0, 0, SCREEN_HEIGHT+20, SCREEN_WIDTH-20)];
        }
    }
    else if (UIInterfaceOrientationIsPortrait(interfaceOrientation)) {
        if (IS_IPHONE_5) {
            [_subscriber.view setFrame:CGRectMake(0, 0, SCREEN_WIDTH, 548)];
        }
        else {
            [_subscriber.view setFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        }
    }
    
    [self.view insertSubview:subscriber.view atIndex:0];
    
    if (loader2 != nil) {
        [loader2 removeFromSuperview];
        loader2 = nil;
    }
}

- (void)publisher:(OTPublisher*)publisher didFailWithError:(OTError*) error {
    NSLog(@"publisher didFailWithError %@", error);
    [self showAlert:[NSString stringWithFormat:@"There was an error publishing."]];
}


- (void)subscriber:(OTSubscriber*)subscriber didFailWithError:(OTError*)error
{
    NSLog(@"subscriber %@ didFailWithError %@", subscriber.stream.streamId, error);
    [self showAlert:[NSString stringWithFormat:@"There was an error subscribing to stream %@", subscriber.stream.streamId]];
}

- (void)stream:(OTStream *)stream didChangeVideoDimensions:(CGSize)dimensions {
    NSLog(@"stream size: %@", NSStringFromCGSize(dimensions));
    
    blReceived = YES;
    if (_subscriber.stream.videoDimensions.width < _subscriber.stream.videoDimensions.height) {
        [self changeSubscriberFeedWithScale:NO];
    }
    else {
        [self changeSubscriberFeedWithScale:YES];
    }
    //UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Stream Size" message:[NSString stringWithFormat:@"Width: %.2f , Height: %.2f", dimensions.width, dimensions.height] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    //[alert show];
}

- (void)session:(OTSession*)session didFailWithError:(OTError*)error {
    NSLog(@"sessionDidFail %@", error.description);
    
    [NSTimer scheduledTimerWithTimeInterval:4.0 target:self selector:@selector(connectWithSession) userInfo:nil repeats:NO];
    // [self showAlert:[NSString stringWithFormat:@"There was an error connecting to session %@", session.sessionId]];
}


- (void)showAlert:(NSString*)string {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Message from video session"
                                                    message:string
                                                   delegate:self
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
}

- (void)changeSubscriberFeedWithScale:(BOOL)blLarge
{
    
    if (_subscriber.stream == nil) {
        return;
    }

    CGFloat originX = 0, originY = 0;
    CGFloat width = (float)SCREEN_WIDTH, height = (float)SCREEN_HEIGHT + 20.0f;
    CGFloat transX, transY, transWidth, transHeight;
    CGFloat scaleX = width / height;
    CGFloat scaleY = height / width;
    
    if (IS_IPHONE_5) {
        height = 568.0f;
    }

    transX = originX;
    transY = originY;
    transWidth = width;
    transHeight = transHeight;
    
    if (self.interfaceOrientation == UIInterfaceOrientationPortrait) {
        
        coverView.frame = CGRectMake(0, 0, width, height);
        
        transY = originY;
        transHeight = height;

        if (blLarge) {

            originY = (height - height * scaleX) / 2;
            height = height * scaleX;
            transX = width/4;
            transWidth = width/2;
        }
    }
    else {
        
        CGFloat temp = width;
        width = height;
        height = temp;
        scaleX = width / height;
        scaleY = height / width;

        coverView.frame = CGRectMake(0, 0, width, height);

        transX = originX;
        transWidth = width;

        if (!blLarge) {
            originX = (width - width * scaleY) / 2;
            width = width * scaleY;
            transY = height/4;
            transHeight = height/2;
        }
    }

    [UIView animateWithDuration:0.4 animations:^(void) {
        _subscriber.view.frame = CGRectMake(originX, originY, width, height);
        [self setCoverviewTransFrame:CGRectMake(transX, transY, transWidth, transHeight)];
        if (!loader2) {
            [coverView setNeedsDisplay];
        }

    }];
    
    NSLog(@"x: %f, y: %f, width: %f, height: %f", transX, transY, transWidth, transHeight);

}

- (void) setCoverviewTransFrame:(CGRect)tramsFrame
{
    coverView.transX = tramsFrame.origin.x;
    coverView.transY = tramsFrame.origin.y;
    coverView.transWidth = tramsFrame.size.width;
    coverView.transHeight = tramsFrame.size.height;
}

#pragma mark - Actions

- (IBAction)arrowTapped:(UIButton *)sender {
    switch (sender.tag) {
        case 0:
            [self showAlert:@"Up Pressed"];
            break;
        case 1:
            [self showAlert:@"Down Pressed"];
            break;
        case 2:
            [self showAlert:@"Left Pressed"];
            break;
        case 3:
            [self showAlert:@"Right Pressed"];
            break;
        default:
            break;
    }
}

- (IBAction)endVideo:(id)sender {
    [_session disconnect];
}

@end

