//
//  ViewController.h
//  SampleApp
//
//  Created by Charley Robinson on 12/13/11.
//  Copyright (c) 2011 Tokbox, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Opentok/Opentok.h>
#import "CustomLoader.h"

@class CustomLoader;
@interface ViewController : UIViewController <OTSessionDelegate, OTSubscriberDelegate, OTPublisherDelegate>

@property (retain, nonatomic) IBOutlet UIView *controls;
@property (retain, nonatomic) IBOutlet UIView *publisherView;
@property (retain, nonatomic) CustomLoader *loader1;
@property (retain, nonatomic) CustomLoader *loader2;
@property (strong, nonatomic) IBOutlet UIButton *videoEnd;
@property (strong, nonatomic) IBOutlet UIView *arrowView;


- (void)doConnect;
- (void)doPublish;
- (void)showAlert:(NSString*)string;

// Video Scale
- (void)changeSubscriberFeedWithScale:(BOOL)blLarge;

- (IBAction)arrowTapped:(UIButton *)sender;
- (IBAction)endVideo:(id)sender;


@end
