//
//  CustomLoader.h
//  Classmon
//
//  Created by Ayaz Alavi on 4/24/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface CustomLoader : UIView

@property (nonatomic, retain) UILabel *message;
@property (nonatomic, retain) UIActivityIndicatorView *activityIndicator;

@end
